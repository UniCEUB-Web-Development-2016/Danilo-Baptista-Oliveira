<?php

include "util/RequestRouter.php";
	

   (new RequestRouter)->route();