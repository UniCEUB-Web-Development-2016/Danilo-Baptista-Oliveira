<?php


class RequestController
{

	public function executeRequest($request)
	{
		$uri = $request->get_uri();
		echo $this->getResource($uri);
		
	}


	public function getResource($uri)
	{
	     $a = explode('?', $uri);
	     return str_replace("&", "</br>", $a[1]);		
	}

	public function createObject($protocol,$method,$uri,$server_name,$server_addr){
		
		$host = new User($protocol,$method,$uri,$server_name,$server_addr);
		(new User)->setRquest($host);

	}	
		


//http://localhost/Class-codes-master/Classes/Class7_Request/?x=10&y=5
}