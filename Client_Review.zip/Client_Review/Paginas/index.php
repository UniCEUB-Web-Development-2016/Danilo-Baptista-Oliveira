<?php include("cabecalho2.php")?>
<center>
        <table>
          <form action="telaLogin.php" method="post" name="form1">
          <tr>
          <td>
          <center>
          <img src="../Imagens/reviewnstore.png" alt="Smiley face" height="100" width="300">
          <br>
              <button class="btn btn-primary" type="Logue na sua conta!" style='height: 60px;width: 160px;background-color: #00688b'action="telaLogin.php"/>Entre agora!</button></center>
              </br>
              </td>                              
              </tr>
              </form>
              </table>
              </center>
              <blockquote>
                   <center>
                        Nossos parceiros:
                        <a href="http://www.americanas.com.br/"><img src="../Imagens/americanas.com.jpg.png"  alt="Smiley face" height="65" width="160" ><br></a>
                        <br>
                        <a href="https://www.mercadolivre.com.br"><img src="../Imagens/MercadoLivre.com.jpg.jpg"  alt="Smiley face" height="65" width="160"><br></a>
                        <br>                            
                        <a href="https://www.submarino.com.br"><img src="../Imagens/submarino.com.jpg.png"  alt="Smiley face" height="65" width="160"><br></a>
                        <br>
                        <a href="https://www.buscape.com.br"><img src="../Imagens/logo-buscape.jpg"  alt="Smiley face" height="65" width="160"><br></a>
                        </center>
              </blockquote> 
<?php include("rodape.php")?>