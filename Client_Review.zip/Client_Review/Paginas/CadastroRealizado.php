<?php include("Cabecalho.php")?>
	                    <center>
                        <table>
                            <tr>
                               <td>
                               <h1> Cadastro Realizado com sucesso! </h1>
                               <br>
                               </td>    
                           </tr>
                           </form>
                       </table>
                       </center>
<?php include("rodape.php")?>