				</div>    
        	</div>
			<footer style="background-color: #ffffff;height:100px;bottom:0;width:100%">
				&copy; ReviewNShop 2016;
			</footer>	
    </body>
</html>